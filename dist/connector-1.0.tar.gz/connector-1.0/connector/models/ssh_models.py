from . import Schema, Optional

ignore_extra_keys = True

SSHCMDRequestSchema = Schema({
    'node_type': str,
    'ssh_username': str,
    Optional('ssh_password'): str,
    'cmd': str,
    'target': str,
    Optional("ssh_private_key"): str,
    Optional("ssh_public_key"): str,
    Optional("opts"): dict
})
