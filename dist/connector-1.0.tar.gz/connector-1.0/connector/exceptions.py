class InvalidTypeError(BaseException):
    pass
