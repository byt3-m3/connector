import os

APP_PORT = os.getenv("APP_PORT", "5001")
DEBUG = os.getenv("DEBUG", True)